module.exports = {
    dependencyFunction1 : (n) => {
        return n+5;
    }
}